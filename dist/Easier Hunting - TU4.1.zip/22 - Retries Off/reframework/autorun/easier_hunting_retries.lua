-- Easier Hunting: quest retries disabled.
return
