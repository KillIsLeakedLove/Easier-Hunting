-- Easier Hunting: quest retries disabled / 任务重试已关闭.
return
